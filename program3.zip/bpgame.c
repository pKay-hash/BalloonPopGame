//Syed Shaban and Syed Mehdi
#define MAX_ROWS 40
#define MAX_COLS 40

#define None '.'    // "air"
#define Red  '^'
#define Blue '='
#define Green 'o'
#define Yellow '+'

// file:  bpgame.c

#include <stdlib.h>
#include <stdio.h>
#include "bpgame.h"
#include <time.h>


/** TYPEDEFS / STRUCTs HERE ***/
/*typedef struct node Node;
struct node {
	int score;
	char **board;
	Node * pNext;
};
typedef struct node Node;
*/
struct bpgame {
	int score;
	int rowNum;
	int colNum;
	char **board;
	int **visitation;
	//Node * pHead;
   // YOU DECIDE WHAT TO PUT IN HERE TO CAPTURE THE STATE OF
   //   A "RUN" OF THE GAME.....


};
typedef struct bpgame BPGame;

BPGame * bp_create(int nrows, int ncols){
	BPGame *pGame;
	srand(time(NULL));
	pGame = malloc((sizeof(char**)*2) + ((sizeof(int) * 3)));
	pGame->score = 0;
	if(nrows > MAX_ROWS || nrows < 0){
		fprintf(stderr, "Error, please choose row within limits.");
		return NULL;
	}
	if(ncols > MAX_COLS || ncols < 0){
		fprintf(stderr, "Error, please choose row within limits.");
                return NULL;
	}
	//pGame->pHead = (Node*)malloc((sizeof(Node)));
	//pGame->pHead = NULL;
	pGame->rowNum = nrows;
	pGame->colNum = ncols;
	pGame->board = (char**)malloc((nrows + 1) * sizeof(char*));
	for (int allocateNum = 0; allocateNum < nrows+1; allocateNum++){
		pGame->board[allocateNum] = (char*)malloc((ncols+1) * sizeof(char));
	}
	pGame->visitation = (int **)malloc((nrows+1) * sizeof(int*));
        for (int allocateNum1 = 0; allocateNum1 < nrows+1; allocateNum1++){
                pGame->visitation[allocateNum1] = (int*)malloc((ncols+1) * sizeof(int));
        }
	int randomVal, i, j;
	for (i = 0; i < nrows; i++){
		for (j = 0; j < ncols; j++){
			randomVal = (rand() % 4);
			switch(randomVal){
				case 0:
					pGame->board[i][j] = Red;
					break;
				case 1:
					pGame->board[i][j] = Blue;
					break;
				case 2:
                                        pGame->board[i][j] = Green;
					break;
				case 3:
                                        pGame->board[i][j] = Yellow;
					break;
			}

		}
	}
	for (i = 0; i < nrows; i++){
		for (j = 0; j < ncols; j++){
			pGame->visitation[i][j] = 0;
		}
	}
	//pGame->pHead->score = pGame->score;
	//pGame->pHead->board = pGame->board;
	//pGame->pHead->pNext = NULL;
	return pGame;
}

BPGame * bp_create_from_mtx(char mtx[][MAX_COLS], int nrows,int ncols){
	int i, j;
	if(nrows > MAX_ROWS || nrows < 0){
                fprintf(stderr, "Error, please choose row within limits.");
                return NULL;
        }
        if(ncols > MAX_COLS || ncols < 0){
                fprintf(stderr, "Error, please choose row within limits.");
                return NULL;
        }
	BPGame *pGame;
	for(i = 0; i < nrows; i++){
		for(j = 0; j < ncols; j++){
			if(mtx[i][j] != None || mtx[i][j] != Red || mtx[i][j] != Blue || mtx[i][j] != Green || mtx[i][j] !=  Yellow){
				fprintf(stderr, "Error, matrix must have valid characters inside.");
				return NULL;
			}
		}
	}

	//pGame->pHead = (Node*)malloc((sizeof(Node)));
	//pGame->pHead = NULL;
	pGame->rowNum = nrows;
	pGame->colNum = ncols;
	pGame->board = (char**)malloc((nrows + 1) * sizeof(char*));
	for (int allocateNum = 0; allocateNum < nrows+1; allocateNum++){
		pGame->board[allocateNum] = (char*)malloc((ncols+1) * sizeof(char));
	}
	pGame->visitation = (int **)malloc((nrows+1) * sizeof(int*));
	for (int allocateNum1 = 0; allocateNum1 < nrows+1; allocateNum1++){
		pGame->visitation[allocateNum1] = (int*)malloc((ncols+1) * sizeof(int));
	}
	for (i = 0; i < nrows; i++){
		for (j = 0; j < ncols; j++){
			pGame->board[i][j] = mtx[i][j];
		}
	}
	for (i = 0; i < nrows; i++){
		for (j = 0; j < ncols; j++){
			pGame->visitation[i][j] = 0;
		}
	}
	//pGame->pHead->score = pGame->score;
	//pGame->pHead->board = pGame->board;
	//pGame->pHead->pNext = NULL;
	return pGame;
}



void bp_destroy(BPGame *b){
	for(int i = 0; i < b->rowNum+1; i++){
		free(b->board[i]);
	}
	free(b->board);
	for(int i = 0; i < b->rowNum+1; i++){
		free(b->visitation[i]);
	}
	free(b->visitation);
	//free(b->pHead);
	free(b);
	return;
}
void bp_display(BPGame * b){
	int nrows = b->rowNum;
	int ncols = b->colNum;
	int curCol, curRow;
	int numDashes = (ncols*2)+1;
	printf("Score: %i\n", b->score);
	printf("   +");
	for(int i = 0; i < numDashes; i++){
		printf("-");
	}
	printf("+\n");
	for(curRow = 0; curRow < nrows; curRow++){
		printf("%2i |", curRow);
		for(curCol = 0; curCol < ncols; curCol++){
			printf(" %c", b->board[curRow][curCol]);
		}
		printf(" |\n");
	}
	//dashes
	printf("   +");
        for(int x = 0; x < numDashes; x++){
                printf("-");
        }
        printf("+\n     ");
	//first digit of the columns
	for(int y = 0; y < ncols; y++){
		printf("%i ", y/10);
	}
	printf("\n     ");
	//second digit of the columns
	for(int z = 0; z < ncols; z++){
		printf("%i ", z%10);
	}
	printf("\n\n");
	return;
}
int _isLonely(BPGame *b, int r, int c, char balloonClr){
	if(balloonClr != None){
	if(r < MAX_ROWS-1 && b->board[r+1][c] == balloonClr){
		if(b->visitation[r+1][c] != 1){	
			return 0;
		}
	}
	if(r > 0 && b->board[r-1][c] == balloonClr){
		if(b->visitation[r-1][c] != 1){
			return 0;
		}
	}
	if(c < MAX_COLS-1 && b->board[r][c+1] == balloonClr){
		if(b->visitation[r][c+1] != 1){
                        return 0;
                }
	}
	if(c > 0 && b->board[r][c-1] == balloonClr){
		if(b->visitation[r][c-1] != 1){
                        return 0;
                }
	}
	}
	return 1;
}

void _bp_pop(BPGame *b, int r, int c){
	char balloonClr;
        balloonClr = b->board[r][c];
	int popCount = 0;
	int origPopped = 0;
	int finalPopped = 0;
	printf("(%d, %d)\n", r, c);
	b->visitation[r][c] = 1;
	if(_isLonely(b, r, c, balloonClr)){
		printf("it is lonely\n");
		return;
        }
        else{
                if(r > 0 && b->board[r-1][c] == balloonClr){
			if(b->visitation[r-1][c] != 1){
				_bp_pop(b, r-1, c);
			}else{
				printf("Nothing up\n");
			}
                }
                if(c < MAX_COLS-1 && b->board[r][c+1] == balloonClr){
                        if(b->visitation[r][c+1] != 1){
                                _bp_pop(b, r, c+1);
			}else{
                                printf("Nothing Right\n");
                        }
		}
                if(r < MAX_ROWS-1 && b->board[r+1][c] == balloonClr){
                        if(b->visitation[r+1][c] != 1){
                                _bp_pop(b, r+1, c);
			}else{
                                printf("Nothing Down\n");
                        }
		}
                if(c > 0 && b->board[r][c-1] == balloonClr){
                        if(b->visitation[r][c-1] != 1){
                                _bp_pop(b, r, c-1);
			}else{
                                printf("Nothing Left\n");
                        }
		}
        }
}
int bp_pop(BPGame *b, int r, int c){
	int i, j;
	int finalPopped = 0;
	_bp_pop(b, r, c);
	for(i = 0; i < b->rowNum; i++){
                for(j = 0; j < b->colNum; j++){
                        if(b->visitation[i][j] == 1){
				finalPopped++;
			}
                }
        }
	if(finalPopped > 1){
		for(i = 0; i < b->rowNum; i++){
                	for(j = 0; j < b->colNum; j++){
                        	if(b->visitation[i][j] == 1){
                                	b->board[i][j] = None;
                        	}
                	}
        	}
	}
	else{
		finalPopped = 0;
	}
	for(i = 0; i < b->rowNum; i++){
		for(j = 0; j < b->colNum; j++){
			b->visitation[i][j] = 0;
		}
	}
	b->score+= finalPopped*(finalPopped -1);
	//Node *pTemp;
	//pTemp->score = b->score;
	//pTemp->board = b->board;
	//pTemp->pNext = b->pHead;
	//b->pHead = pTemp;
	return finalPopped;
	

	//pseudo - code
	//	getColor;
	//	have counter for amount of balloons popped
	//	base case(if checkAllDirections == false?) {
	//		return 0; (i think)//add 0 to counter and then it should have a ripple effect on the previous recursive calls
	//	}
	//	check all directions for same color 
	//		if b->board[r+col_row_Moves[0]][c] == same balloon{ return counter + bp_pop(b, r+col_row_Moves,c)}//same for other if statements
	//		if b->board[r+col_row_Moves[1][c] == same balloon{};
	//		if b->board[r][c+col_row_Moves[0]] == same balloon{};
	//		if b-board[r][c+col_row_Moves[1]] == same balloon{} ; 
	//gonna have to actually pop somehwere amongst this 


}
int bp_is_compact(BPGame * b){
	int j, i;
	for(j = 0; j < b->colNum; j++){
		for(i = 0; i < b->rowNum; i++){
			if(b->board[i][j] == None){
				while(i+1 != b->rowNum){
					if(b->board[i+1][j] != None){
						return 0;
					}
					i++;	
				}
			}
		}
	}
	return 1;
}

int bp_score(BPGame *b){
	int score = b->score;
	return score;
}

int bp_get_balloon(BPGame *b, int r, int c){
	if(b->board[r][c] == Red)
		return 0;
	else if(b->board[r][c] == Blue)
		return 1;
	else if(b->board[r][c] == Green)
		return 2;
	else if (b->board[r][c] == Yellow)
		return 3;
	else{
		return -1;
	}
	return -1;
}

int bp_can_pop(BPGame *b){
	char balloonClr;
	for (int i = 0; i < b->rowNum; i++){
		for(int j = 0; j < b->colNum; j++){
			balloonClr = b->board[i][j];
			if(!(_isLonely(b,i,j, balloonClr))){
				return 1;
			}
		}
	}
	return 0;
}
void _bp_float_one_step(BPGame *b){
	int i, j;
        int isNum = 0;
        for(i = 1; i < b->rowNum; i++){
                for(j = 0; j < b->colNum; j++){
                        if(b->board[i][j] != None){
                                if(b->board[i-1][j] == None){
                                        b->board[i-1][j] = b->board[i][j];
                                        b->board[i][j] = None;
                                        isNum = 1;
                                }
                        }
                }
                if (isNum == 1){
                        return;
                }
        }
}
void bp_float_one_step(BPGame *b){
	_bp_float_one_step(b);
	//_bp_float_one_step(b);
}

int bp_undo(BPGame * b){
 	/*if(b->pHead->pNext == NULL){
		return 0;
	}
	Node * pTemp;
	pTemp = b->pHead;
	b->pHead = b->pHead->pNext;
	*/
	return 1;
}
/*
int main(int argc, char *argv[]){
	int rows, cols;
	int rowInput, colInput;
	BPGame *pGame;
	//if (argc > 1){
	//	if((sscanf(argv[1], "%i", &rows) == 1) && (sscanf(argv[2], "%i", &cols) == 1)){
	//		if(((rows <= MAX_ROWS) && (cols <= MAX_COLS)))
	//			pGame = bp_create(argv[1], argv[2]);
	//	}
	//}
	//else{
	pGame = bp_create(12, 12);
	//}
	bp_display(pGame);
	//scanf("Enter a row and column: %d %d", &rowInput, &colInput);
	bp_pop(pGame, 1, 1);
	while(!(bp_is_compact(pGame))){
		bp_display(pGame);
		bp_float_one_step(pGame);
	}
	bp_float_one_step(pGame);
	bp_display(pGame);
	bp_destroy(pGame);
	return 1;
}*/
/*** IMPLEMENTATION OF bp_XXXX FUNCTIONS HERE  ****/

